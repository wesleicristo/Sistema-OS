from Views import telaPrincipal

def main():
    exec(telaPrincipal)

if __name__ == "__main__":
    main()