import datetime
import tkinter as tk
from Controllers import controller
from tkinter import messagebox

class TelaDetalhes:
    def __init__(self, master, numeroos=None, matriculaLogin=None, cargoLogin=None, opNovaOS=False):
        self.master = master
        self.master.title("Detalhes OS")
        self.largura = 1000
        self.altura = 810
        self.master.geometry(f"{self.largura}x{self.altura}+"
                             f"{(self.master.winfo_screenwidth() // 2) - (self.largura // 2)}+"
                             f"{(self.master.winfo_screenheight() // 2) - (self.altura // 2)}")
        self.master.grab_set()

        self.numeroos = numeroos
        self.matriculaLogin = matriculaLogin
        self.cargoLogin = cargoLogin

        self.listaExecutoresSelec = []

        # Criação do primeiro quadro da area de                                                     INFORMAÇÕES DA OS
        self.quadro_OS = tk.Frame(self.master)
        self.quadro_OS.pack()

        self.lbl_Ordem_servico = tk.Label(self.quadro_OS, text="Ordem de Serviço", font=("Arial", 12, "bold"))
        self.lbl_Ordem_servico.pack()

        self.subquadro1 = tk.Frame(self.quadro_OS)
        self.subquadro1.pack()

        # Id
        self.lbl_Id = tk.Label(self.subquadro1, text="ID OS:")
        self.lbl_Id.grid(row=0, column=0, sticky="w")
        self.txb_Id = tk.Entry(self.subquadro1, width=6)
        self.txb_Id.grid(row=1, column=0, padx=5)

        # Titulo
        self.lbl_Titulo = tk.Label(self.subquadro1, text="Titulo")
        self.lbl_Titulo.grid(row=0, column=1, sticky="w")
        self.txb_Titulo = tk.Entry(self.subquadro1, width=40)
        self.txb_Titulo.grid(row=1, column=1, padx=5)

        # Unidade
        self.lbl_Unidade = tk.Label(self.subquadro1, text="Unidade")
        self.lbl_Unidade.grid(row=0, column=2, sticky="w")
        self.txb_Unidade = tk.Entry(self.subquadro1, width=20)
        self.txb_Unidade.grid(row=1, column=2, padx=5)

        # Data Criação OS
        self.lbl_Dt_Criação = tk.Label(self.subquadro1, text="Data Inicio:")
        self.lbl_Dt_Criação.grid(row=0, column=3, sticky="w")
        self.txb_Dt_Criação = tk.Entry(self.subquadro1, width=12)
        self.txb_Dt_Criação.grid(row=1, column=3, padx=5)

        # Data Fechamento OS
        self.lbl_Dt_Fechamento = tk.Label(self.subquadro1, text="Data Fim")
        self.lbl_Dt_Fechamento.grid(row=0, column=4, sticky="w")
        self.txb_Dt_Fechamento = tk.Entry(self.subquadro1, width=12)
        self.txb_Dt_Fechamento.grid(row=1, column=4, padx=5)

        # Tipo do Serviço
        self.lbl_Tp_Serviço = tk.Label(self.subquadro1, text="Tipo Serviço")
        self.lbl_Tp_Serviço.grid(row=0, column=5, sticky="w")
        '''self.txb_Tp_Serviço = tk.Entry(self.subquadro1, width=15)
        self.txb_Tp_Serviço.grid(row=1, column=5, padx=5)'''

        # Tipo do Servico
        self.op_dpb_tipo_os = ["Eletrica", "Hidraulica", "Informatica"]
        self.sel_dpb_tipo_os = tk.StringVar()
        self.sel_dpb_tipo_os.set(self.op_dpb_tipo_os[0])
        self.dpb_tipo_os = tk.OptionMenu(self.subquadro1, self.sel_dpb_tipo_os, *self.op_dpb_tipo_os)
        self.dpb_tipo_os.grid(row=1, column=5, padx=5)

        # Funcionario Criação OS
        self.lbl_Funcionario = tk.Label(self.subquadro1, text="Requisitante")
        self.lbl_Funcionario.grid(row=0, column=6, sticky="w")
        self.txb_Funcionario = tk.Entry(self.subquadro1, width=30)
        self.txb_Funcionario.grid(row=1, column=6, padx=5)

        self.subquadro2 = tk.Frame(self.quadro_OS, padx=10, pady=10)
        self.subquadro2.pack()
        # Descrição da Solicitação da OS
        self.lbl_Descricao = tk.Label(self.subquadro2, text="Descrição: ")
        self.lbl_Descricao.grid(row=0, column=0, sticky="w")

        self.txb_Descricao = tk.Text(self.subquadro2, height=5, width=110)
        self.txb_Descricao.grid(row=1, column=0, sticky="e")

        # Criação do segundo quadro da area de                                              INFORMAÇÕES DO PLANEJAMENTO
        self.quadro_Planejamento = tk.Frame(self.master, padx=5, pady=5)
        self.quadro_Planejamento.pack()

        self.lbl_Planejamento = tk.Label(self.quadro_Planejamento, text="Planejamento", font=("Arial", 12, "bold"))
        self.lbl_Planejamento.pack()

        self.quadro2_subquadro1 = tk.Frame(self.quadro_Planejamento, pady=10, padx=10)
        self.quadro2_subquadro1.pack()

        self.plan_lbl_Id = tk.Label(self.quadro2_subquadro1, text="ID Plano:")
        self.plan_lbl_Id.grid(row=0, column=0, sticky="w")
        self.plan_txb_Id = tk.Entry(self.quadro2_subquadro1, width=12)
        self.plan_txb_Id.grid(row=1, column=0, padx=5)

        self.plan_lbl_Ini = tk.Label(self.quadro2_subquadro1, text="Dt Inicio")
        self.plan_lbl_Ini.grid(row=0, column=1, sticky="w")
        self.plan_txb_Ini = tk.Entry(self.quadro2_subquadro1, width=12)
        self.plan_txb_Ini.grid(row=1, column=1, padx=5)

        self.plan_lbl_Fim = tk.Label(self.quadro2_subquadro1, text="Dt Fim")
        self.plan_lbl_Fim.grid(row=0, column=2, sticky="w")
        self.plan_txb_Fim = tk.Entry(self.quadro2_subquadro1, width=12)
        self.plan_txb_Fim.grid(row=1, column=2, padx=5)

        self.plan_lbl_Planejista = tk.Label(self.quadro2_subquadro1, text="Projetista")
        self.plan_lbl_Planejista.grid(row=0, column=3, sticky="w")
        self.plan_txb_Planejista = tk.Entry(self.quadro2_subquadro1, width=30)
        self.plan_txb_Planejista.grid(row=1, column=3, padx=5)

        self.quadro2_subquadro2 = tk.Frame(self.quadro_Planejamento, pady=10, padx=10)
        self.quadro2_subquadro2.pack()

        self.plan_lbl_Descricao = tk.Label(self.quadro2_subquadro2, text="Descrição: ")
        self.plan_lbl_Descricao.grid(row=0, column=0, sticky="w")

        self.plan_txb_Descricao = tk.Text(self.quadro2_subquadro2, height=5, width=110)
        self.plan_txb_Descricao.grid(row=1, column=0, sticky="e")

        # Criação do terceiro quadro da area de                                              INFORMAÇÕES DA EXECUÇÃO
        self.quadro_Execucao = tk.Frame(self.master, padx=10, pady=10)
        self.quadro_Execucao.pack()

        self.exec_lbl_Planejamento = tk.Label(self.quadro_Execucao, text="Execução", font=("Arial", 12, "bold"))
        self.exec_lbl_Planejamento.pack()

        self.quadroExec_subquadro1 = tk.Frame(self.quadro_Execucao, pady=10, padx=10)
        self.quadroExec_subquadro1.pack()

        self.exec_lbl_Id = tk.Label(self.quadroExec_subquadro1, text="ID Execução:")
        self.exec_lbl_Id.grid(row=0, column=0, sticky="w")
        self.exec_txb_Id = tk.Entry(self.quadroExec_subquadro1, width=12)
        self.exec_txb_Id.grid(row=1, column=0, padx=5)

        self.exec_lbl_Ini = tk.Label(self.quadroExec_subquadro1, text="Dt Inicio")
        self.exec_lbl_Ini.grid(row=0, column=1, sticky="w")
        self.exec_txb_Ini = tk.Entry(self.quadroExec_subquadro1, width=12)
        self.exec_txb_Ini.grid(row=1, column=1, padx=5)

        self.exec_lbl_Fim = tk.Label(self.quadroExec_subquadro1, text="Dt Fim")
        self.exec_lbl_Fim.grid(row=0, column=2, sticky="w")
        self.exec_txb_Fim = tk.Entry(self.quadroExec_subquadro1, width=12)
        self.exec_txb_Fim.grid(row=1, column=2, padx=5)

        self.exec_lbl_VlrMaoObra = tk.Label(self.quadroExec_subquadro1, text="Valor Mão-Obra")
        self.exec_lbl_VlrMaoObra.grid(row=0, column=3, sticky="w")
        self.exec_txb_VlrMaoObra = tk.Entry(self.quadroExec_subquadro1, width=30)
        self.exec_txb_VlrMaoObra.grid(row=1, column=3, padx=5)

        self.quadroExec_subquadro2 = tk.Frame(self.quadro_Execucao, pady=10, padx=10)
        self.quadroExec_subquadro2.pack()

        self.exec_lbl_Descricao = tk.Label(self.quadroExec_subquadro2, text="Descrição: ")
        self.exec_lbl_Descricao.grid(row=0, column=0, sticky="w")

        self.exec_txb_Descricao = tk.Text(self.quadroExec_subquadro2, height=10, width=95)
        self.exec_txb_Descricao.grid(row=1, column=0, sticky="e")

        self.exec_lbl_executores = tk.Label(self.quadroExec_subquadro2, text="Executores")
        self.exec_lbl_executores.grid(row=0, column=2)
        self.exec_lista_executores = tk.Listbox(self.quadroExec_subquadro2)
        self.exec_lista_executores.grid(row=1, column=2)

        self.exec_btn_SelExec = tk.Button(self.quadro_Execucao, text="Sel Executor", command=self.selecionar_Executor)
        self.exec_btn_SelExec.pack(side="right")

        # Criação do quarto quadro da area de                                              BOTOES DE RODAPÉ
        self.quadro4 = tk.Frame(self.master, padx=10, pady=1)
        self.quadro4.pack()

        if opNovaOS:
            self.btn_NovaOS = tk.Button(self.quadro4, text="Salvar Nova OS", width=15, height=2, command=self.salvar_NovaOS)
            self.btn_NovaOS.grid(row=0, column=0)
        else:
            self.btn_Teste = tk.Button(self.quadro4, text="Salvar", width=15, height=2, command=self.alterar_OS)
            self.btn_Teste.grid(row=0, column=0)

            self.btn_GerarPDF = tk.Button(self.quadro4, text="PDF (Beta)", width=15, height=2, command=self.imprimir_Relatorio)
            self.btn_GerarPDF.grid(row=0, column=1)

        if numeroos:
            self.buscar_Detalhes()
        elif matriculaLogin:
            self.busca_Info_NovaOS()

        self.disponibilizar_Campos(cargo=cargoLogin)

    def disponibilizar_Campos(self, cargo):
        self.txb_Id.configure(state='disable')
        self.plan_txb_Id.configure(state='disable')
        self.exec_txb_Id.configure(state='disable')
        self.txb_Dt_Criação.configure(state='disable')
        self.txb_Dt_Fechamento.configure(state='disable')
        self.plan_txb_Ini.configure(state='disable')
        self.plan_txb_Fim.configure(state='disable')
        self.exec_txb_Ini.configure(state='disable')
        self.exec_txb_Fim.configure(state='disable')
        self.txb_Funcionario.configure(state='disable')
        self.plan_txb_Planejista.configure(state='disable')
        self.txb_Unidade.configure(state='disable')

        def desativar_Frame(frame:tk.Frame):
            for wid in frame.winfo_children():
                if isinstance(wid, tk.Frame):
                    desativar_Frame(wid)
                else:
                    wid.configure(state='disabled')

        if cargo == "Gerente":
            desativar_Frame(self.quadro_Planejamento)
            desativar_Frame(self.quadro_Execucao)
        elif cargo == "Projetista":
            desativar_Frame(self.quadro_OS)
            desativar_Frame(self.quadro_Execucao)
        elif cargo == "Executor":
            desativar_Frame(self.quadro_OS)
            desativar_Frame(self.quadro_Planejamento)

    def buscar_Detalhes(self):
        resultadoOS = None
        resultadoPlan = None
        resultadoExec = None
        executores = None
        resultadoOS, resultadoPlan, resultadoExec, executores = controller.pesquisar_Detalhes(numeroos=self.numeroos)

        if resultadoOS:
            self.txb_Id.insert(0, str(resultadoOS[0]))
            self.txb_Titulo.insert(0, str(resultadoOS[1]))
            self.txb_Unidade.insert(0, str(resultadoOS[2]))
            self.txb_Dt_Criação.insert(0, str(resultadoOS[3].date()))
            try:
                self.txb_Dt_Fechamento.insert(0, str(resultadoOS[4].date()))
            except:
                self.txb_Dt_Fechamento.insert(0, "--")
            if str(resultadoOS[5]) == "Eletrica":
                self.sel_dpb_tipo_os.set(self.op_dpb_tipo_os[0])
            elif str(resultadoOS[5]) == "Hidraulica":
                self.sel_dpb_tipo_os.set(self.op_dpb_tipo_os[1])
            elif str(resultadoOS[5]) == "Informatica":
                self.sel_dpb_tipo_os.set(self.op_dpb_tipo_os[2])
            else:
                self.op_dpb_tipo_os.remove()
            #self.txb_Tp_Serviço.insert(0, str(resultadoOS[5]))
            self.txb_Funcionario.insert(0, str(resultadoOS[6]))
            self.txb_Descricao.insert(tk.END, str(resultadoOS[7]))
        if resultadoPlan:
            self.plan_txb_Id.insert(0,str(resultadoPlan[0]))
            self.plan_txb_Ini.insert(0, str(resultadoPlan[1].date()))
            self.plan_txb_Fim.insert(0, str(resultadoPlan[2].date()))
            self.plan_txb_Planejista.insert(0, str(resultadoPlan[3]))
            self.plan_txb_Descricao.insert(tk.END, str(resultadoPlan[4]))
        if resultadoExec:
            self.exec_txb_Id.insert(0, str(resultadoExec[0]))
            self.exec_txb_Ini.insert(0, str(resultadoExec[1].date()))
            self.exec_txb_Fim.insert(0, str(resultadoExec[2].date()))
            self.exec_txb_VlrMaoObra.insert(0, str(resultadoExec[3]))
            self.exec_txb_Descricao.insert(tk.END, str(resultadoExec[4]))

            for item in executores:
                print(f"it: {item} - {type(item)}")
                self.exec_lista_executores.insert(tk.END, item)

    def busca_Info_NovaOS(self):
        resultadoUltID = None
        resultadoInfFunc = None
        dataAtual = datetime.date.today()
        resultadoUltID, resultadoInfFunc = controller.pesquisa_Ultima_OS(self.matriculaLogin)
        self.txb_Id.insert(0, str(resultadoUltID))
        self.txb_Dt_Criação.insert(0, str(dataAtual))
        self.txb_Unidade.insert(0, resultadoInfFunc[0])
        self.txb_Funcionario.insert(0, resultadoInfFunc[1])

    def salvar_NovaOS(self):
        sucesso = False
        idOS = self.txb_Id.get()
        titulo = self.txb_Titulo.get()
        dtInicio = self.txb_Dt_Criação.get()
        tpOS = self.sel_dpb_tipo_os.get()
        descrSolic = self.txb_Descricao.get("1.0","end-1c")
        funcCria = self.matriculaLogin
        linha = [idOS,titulo,descrSolic,dtInicio,tpOS,funcCria]
        if messagebox.askyesno("Confirmação","Deseja realmente gravar estas informações?"):
            sucesso = controller.salvar_NovaOS(linha)
        if sucesso:
            messagebox.showinfo("Confirmação","Novo cadastro realizado com sucesso!")
        else:
            messagebox.showerror("Erro!", "Erro na gravação, verificar Log!")
        self.master.destroy()

    def salvar_NovoPlan(self):
        sucesso = False
        idPlan = controller.pesquisa_Ultimo_Plan()
        dt_inicio = str(datetime.date.today())
        dt_fim = dt_inicio
        projetista = str(self.matriculaLogin)
        descricao = self.plan_txb_Descricao.get("1.0","end-1c")
        numeroOS = self.numeroos
        linha = [idPlan, descricao, dt_inicio, dt_fim, projetista, self.numeroos]
        if messagebox.askyesno("Confirmação", "Deseja realmente gravar estas informações?"):
            sucesso = controller.salvar_NovoPlan(linha)
        if sucesso:
            messagebox.showinfo("Confirmação", "Cadastro realizado com sucesso!")
        else:
            messagebox.showerror("Erro!", "Erro na gravação, verificar Log!")
        self.master.destroy()

    def salvar_NovoExec(self):
        sucesso = False
        idExec = controller.pesquisa_Ultimo_Exec()
        dt_inicio = str(datetime.date.today())
        dt_fim = dt_inicio
        vl_MaoObra = self.exec_txb_VlrMaoObra.get() # IMPLEMENTAR LIMITAÇÃO DO CAMPO
        desc_RelatocioExec = self.exec_txb_Descricao.get("1.0", "end-1c")
        executores = self.listaExecutoresSelec
        executores.append(self.matriculaLogin)# IMPLEMENTAR ADIÇÃO DE EXECUTORES
        linha = [idExec, desc_RelatocioExec, dt_inicio, dt_fim, vl_MaoObra, self.numeroos]
        if messagebox.askyesno("Confirmação", "Deseja realmente gravar estas informações?"):
            sucesso = controller.salvar_NovoExec(linha, executores)
        if sucesso:
            messagebox.showinfo("Confirmação", "Cadastro realizado com sucesso!")
        else:
            messagebox.showerror("Erro!", "Erro na gravação, verificar Log!")
        self.master.destroy()
        pass

    def alterar_OS(self):
        sucesso = False
        if self.cargoLogin == "Gerente":
            titulo = self.txb_Titulo.get()
            tpOS = self.sel_dpb_tipo_os.get()
            descrSolic = self.txb_Descricao.get("1.0","end-1c")
            linha = [titulo,tpOS,descrSolic]
            if messagebox.askyesno("Confirmação","Deseja realmente alterar as informações desta OS?"):
                sucesso = controller.alterar_OS(self.numeroos, linha)
            if sucesso:
                messagebox.showinfo("Confirmação", "Atualização realizado com sucesso!")
            else:
                messagebox.showerror("Erro!", "Erro na gravação, verificar Log!")
            self.master.destroy()
        elif self.cargoLogin == "Projetista":
            if not self.plan_txb_Id.get():
                self.salvar_NovoPlan()
        elif self.cargoLogin == "Executor":
            if not self.exec_txb_Id.get():
                if self.plan_txb_Id.get():
                    self.salvar_NovoExec()
                else:
                    messagebox.showerror("Erro!", "Não pode inserir EXECUÇÃO sem existir PLANEJAMENTO")

    def selecionar_Executor(self):
        janela_SelExecutor = tk.Toplevel(self.master)
        janela_SelExecutor.title("Selecionar Funcionario")
        largura, altura = 200, 400
        janela_SelExecutor.geometry(f"{largura}x{altura}+"
                             f"{(janela_SelExecutor.winfo_screenwidth() // 2) - (largura // 2)}+"
                             f"{(janela_SelExecutor.winfo_screenheight() // 2) - (altura // 2)}")

        matrExecutores = controller.pesquisa_Executores(self.matriculaLogin)[0]
        nomeExecutores = controller.pesquisa_Executores(self.matriculaLogin)[1]
        print(f"{matrExecutores}")
        print(f"{nomeExecutores}")
        listaNomeSelec = []
        listaMatrSelec = []
        def adicionar_Funcionario():
            nomeSelec = lista_Func.get(tk.ACTIVE)
            print(f"{nomeSelec}")
            if nomeSelec not in listaNomeSelec:
                listaNomeSelec.append(nomeSelec)
                listaMatrSelec.append(matrExecutores[lista_Func.curselection()[0]])
                lista_Func_Selec.insert(tk.END, nomeSelec)

        def confirmar_Selecao():
            for funcionario in listaNomeSelec:
                self.exec_lista_executores.insert(tk.END, funcionario)
                self.listaExecutoresSelec = listaMatrSelec
                print(f"Nome: {listaNomeSelec}")
                print(f"Nome: {listaMatrSelec}")
            janela_SelExecutor.destroy()
            pass

        lista_Func = tk.Listbox(janela_SelExecutor, selectmode=tk.SINGLE)
        for funcionario in nomeExecutores:
            lista_Func.insert(tk.END, funcionario)
        lista_Func.pack()

        btn_adicionar = tk.Button(janela_SelExecutor, text="Adicionar", command=adicionar_Funcionario)
        btn_adicionar.pack()

        lista_Func_Selec = tk.Listbox(janela_SelExecutor)
        lista_Func_Selec.pack()

        btn_Confirmar = tk.Button(janela_SelExecutor, text="Confirmar", command=confirmar_Selecao)
        btn_Confirmar.pack()

    def imprimir_Relatorio(self):
        linhaOS = [self.txb_Id.get(), self.txb_Titulo.get(), self.txb_Unidade.get(), self.txb_Dt_Criação, self.txb_Dt_Fechamento, self.dpb_tipo_os]
        controller.gerarPDF()
        pass

def iniciar_Detalhes_OS(master, numeroos, cargo, matricula):
    root = tk.Toplevel(master)
    app = TelaDetalhes(root, numeroos=numeroos, cargoLogin=cargo, matriculaLogin=matricula)
    root.mainloop()

def iniciar_Detalhes_NovaOS(master, matriculaLogin):
    root = tk.Toplevel(master)
    app = TelaDetalhes(root, matriculaLogin=matriculaLogin, opNovaOS=True, cargoLogin="Gerente")
    root.mainloop()
