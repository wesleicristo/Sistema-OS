import tkinter as tk

class TelaLogin:
    def __init__(self, master, msg):
        self.master = master
        self.master.title("Tela de Login")
        self.largura = 200
        self.altura = 160
        self.master.geometry(f"{self.largura}x{self.altura}+"
                             f"{(self.master.winfo_screenwidth() // 2) - (self.largura // 2)}+"
                             f"{(self.master.winfo_screenheight() // 2) - (self.altura // 2)}")
        self.master.bind("<KeyPress>",self.verif_Enter)
        master.overrideredirect(True)

        self.matricula = '0'
        self.senha = '0'

        self.lbl_espacador1 = tk.Label(self.master, text="")
        self.lbl_espacador1.pack()
        self.lbl_telalogin = tk.Label(self.master, text="Sistema OS", font=("Arial", 14, "bold"))
        self.lbl_telalogin.pack()
        self.lbl_espacador2 = tk.Label(self.master, text=str(msg))
        self.lbl_espacador2.pack()

        # Criando os widgets
        self.quadro1 = tk.Frame(self.master)
        self.quadro1.pack()

        self.lbl_usuario = tk.Label(self.quadro1, text="Usuário:")
        self.lbl_usuario.grid(row=0, column=0, sticky="e")
        self.txb_usuario = tk.Entry(self.quadro1)
        self.txb_usuario.grid(row=0, column=1)

        self.lbl_senha = tk.Label(self.quadro1, text="Senha:")
        self.lbl_senha.grid(row=1, column=0, sticky="e")
        self.txb_senha = tk.Entry(self.quadro1, show="*")
        self.txb_senha.grid(row=1, column=1)

        self.quadro2 = tk.Frame(self.master)
        self.quadro2.configure(pady=10)
        self.quadro2.pack()

        self.btn_login = tk.Button(self.quadro2, text="Login", command=self.verificar_Login)
        self.btn_login.grid(row=1, column=1)

        self.separador = tk.Frame(self.quadro2)
        self.separador.grid(row=1, column=2)
        self.separador["width"] = 10

        self.btn_cancelar = tk.Button(self.quadro2, text="Cancelar", command=quit)
        self.btn_cancelar.grid(row=1, column=3)

        self.txb_usuario.focus_set()

    def verificar_Login(self):
        self.matricula = self.txb_usuario.get()
        self.senha = self.txb_senha.get()
        self.master.destroy()

    def verif_Enter(self,event):
        if event.keysym == "Return":
            self.verificar_Login()

def iniciar_Tela_Login(msg):
    root = tk.Tk()
    app = TelaLogin(root, msg)
    root.mainloop()
    return app.matricula, app.senha
