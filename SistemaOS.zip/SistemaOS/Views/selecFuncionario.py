import tkinter as tk
from Controllers import controller

class SelecionaExecutores:
    def __init__(self, master):
        self.master = master
        self.master.title("Selecione funcionario")
        self.largura = 200
        self.altura = 100
        self.master.geometry(f"{self.largura}x{self.altura}+"
                             f"{(self.master.winfo_screenwidth() // 2) - (self.largura // 2)}+"
                             f"{(self.master.winfo_screenheight() // 2) - (self.altura // 2)}")
        self.master.grab_set()

        self.quadro_Func = tk.Frame(self.master)
        self.quadro_Func.pack()

        self.sel_NomeExecutor = None
        self.sel_MatriculaExecutor = None

        self.lbl_selecFunc = tk.Label(self.quadro_Func, text="Executor", font=("Arial", 12, "bold"))
        self.lbl_selecFunc.grid(row=0, column=0)

        self.op_dpb_Funcionario = controller.pesquisa_Executores()[1]
        self.sel_dpb_Funcionario = tk.StringVar()
        self.sel_dpb_Funcionario.set(self.op_dpb_Funcionario[0])
        self.dpb_Funcionario = tk.OptionMenu(self.quadro_Func, self.sel_dpb_Funcionario, *self.op_dpb_Funcionario)
        self.dpb_Funcionario.grid(row=1, column=0)

        self.quadro_Botoes = tk.Frame(self.master)
        self.quadro_Botoes.pack()

        self.btn_Selec = tk.Button(self.quadro_Botoes, text="Selecionar", command=self.retorna_Selec)
        self.btn_Selec.grid(row=0, column=0)

        self.btn_Cancel = tk.Button(self.quadro_Botoes, text="Cancelar", command=self.destroi_Janela)
        self.btn_Cancel.grid(row=0, column=1)

    def destroi_Janela(self):
        self.master.destroy()

    def retorna_Selec(self):
        self.sel_MatriculaExecutor = self.op_dpb_Funcionario.index(self.sel_dpb_Funcionario.get())
        self.sel_NomeExecutor = self.sel_dpb_Funcionario.get()

def inicia_SelecExecutor(master):
    root = tk.Toplevel(master)
    app = SelecionaExecutores(root)
    root.mainloop()