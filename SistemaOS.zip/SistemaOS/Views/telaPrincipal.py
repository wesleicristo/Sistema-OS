import tkinter as tk
from tkinter import ttk
from Controllers import controller
from Views import telaDetalhes

class TelaPrincipal:
    def __init__(self, master, login=None, cargo=None):
        self.master = master
        master.title("Sistema OS")
        self.largura = 1550
        self.altura = 550
        master.geometry(f"{self.largura}x{self.altura}+"
                             f"{(self.master.winfo_screenwidth()//2)- (self.largura//2)}+"
                             f"{(self.master.winfo_screenheight()//2)- (self.altura//2)}")

        self.matricula = login
        self.cargo = cargo

        self.lbl_Login = tk.Label(self.master, text=(f"Matricula: {self.matricula} - Cargo: {self.cargo}"), font=("Arial", 12, "bold"))
        self.lbl_Login.pack()

        self.frm_pesquisa = tk.Frame(self.master)
        self.frm_pesquisa.pack()

        self.lbl_nOS = tk.Label(self.frm_pesquisa, text="Numero")
        self.lbl_nOS.grid(row=0, column=0)

        self.txb_nOS = tk.Entry(self.frm_pesquisa)
        self.txb_nOS.grid(row=1, column=0)

        self.lbl_unidade = tk.Label(self.frm_pesquisa, text="Unidade")
        self.lbl_unidade.grid(row=0, column=1)

        self.txb_unidade = tk.Entry(self.frm_pesquisa)
        self.txb_unidade.grid(row=1, column=1)

        self.lbl_tipo_os = tk.Label(self.frm_pesquisa, text="Tipo")
        self.lbl_tipo_os.grid(row=0, column=2)

        self.op_dpd_tipo_os = ["Tudo", "Eletrica", "Hidraulica", "Informatica"]
        self.sel_dpd_tipo_os = tk.StringVar()
        self.sel_dpd_tipo_os.set(self.op_dpd_tipo_os[0])
        self.dpd_tipo_os = tk.OptionMenu(self.frm_pesquisa, self.sel_dpd_tipo_os, *self.op_dpd_tipo_os)
        self.dpd_tipo_os.grid(row=1, column=2)

        self.lbl_status_os = tk.Label(self.frm_pesquisa, text="Estado")
        self.lbl_status_os.grid(row=0, column=3)

        self.op_dpd_status_os = ["Tudo", "Aberta", "Fechada"]
        self.sel_dpd_status_os = tk.StringVar()
        self.sel_dpd_status_os.set(self.op_dpd_status_os[0])
        self.dpd_status_os = tk.OptionMenu(self.frm_pesquisa, self.sel_dpd_status_os, *self.op_dpd_status_os)
        self.dpd_status_os.grid(row=1, column=3)

        self.btn_pesquisa = tk.Button(self.frm_pesquisa, text="Pesquisar", command=self.pesquisar_OS)           # PESQUISA
        self.btn_pesquisa.grid(row=1, column=4)

        self.frm_lista = tk.Frame(self.master)
        self.frm_lista.pack()

        self.tabela = ttk.Treeview(self.frm_lista)
        self.tabela["columns"] = (
        "ID", "Titulo", "Unidade", "Descrição", "Dt_Criação", "Dt_Fechamento", "Tp_Serviço", "Funcionario")
        self.tabela.heading("ID", text="ID")
        self.tabela.heading("Titulo", text="Titulo")
        self.tabela.heading("Unidade", text="Unidade")
        self.tabela.heading("Descrição", text="Descrição")
        self.tabela.heading("Dt_Criação", text="DtIni")
        self.tabela.heading("Dt_Fechamento", text="DtFim")
        self.tabela.heading("Tp_Serviço", text="Tipo")
        self.tabela.heading("Funcionario", text="Funcionario")

        self.tabela.column("#0", width=0, stretch=tk.NO)
        self.tabela.column("ID", width=50)
        self.tabela.column("Titulo", width=140)
        self.tabela.column("Unidade", width=120)
        self.tabela.column("Descrição", width=800)
        self.tabela.column("Dt_Criação", width=69)
        self.tabela.column("Dt_Fechamento", width=69)
        self.tabela.column("Tp_Serviço", width=140)
        self.tabela.column("Funcionario", width=140)

        self.tabela.configure(height=20)
        self.tabela.grid(row=0, column=0)

        self.frm_opcoes = tk.Frame(self.master)
        self.frm_opcoes.pack(side='left')

        self.btn_novaOS = tk.Button(self.frm_opcoes, text="Nova OS", state='disable', command=self.abrir_Criar_NovaOS)
        self.btn_novaOS.grid(row=0, column=0)

        self.btn_detalhesOS = tk.Button(self.frm_opcoes, text="Mostrar Detalhes", command=self.abrir_DetalheOS)
        self.btn_detalhesOS.grid(row=0, column=1)

        if self.cargo == "Gerente":
            self.lbl_unidade.configure(state='disable')
            self.txb_unidade.configure(state='disable')
            self.btn_novaOS.configure(state='normal')

    def preencher_Tabela(self, lista):

        self.tabela.delete(*self.tabela.get_children())
        for i in lista:
            self.tabela.insert(parent="",index="end",values=i)

    def pesquisar_OS(self):
        idos = self.txb_nOS.get()
        unidade = self.txb_unidade.get()
        tpos = self.sel_dpd_tipo_os.get()
        estadoos = self.sel_dpd_status_os.get()

        self.preencher_Tabela(controller.pesquisar_OS(idos, unidade, tpos, estadoos))

    def abrir_DetalheOS(self):
        posselec = None
        valselec = None
        try:
            posselec = self.tabela.selection()
            valselec = self.tabela.item(self.tabela.selection(), "values")[0]
        except:
            posselec = None
        if posselec:
            telaDetalhes.iniciar_Detalhes_OS(self.master,valselec,self.cargo, self.matricula)

    def abrir_Criar_NovaOS(self):
        telaDetalhes.iniciar_Detalhes_NovaOS(self.master, self.matricula)

def iniciar_Tela_Principal(login=None, cargo=None):
    root = tk.Tk()
    app = TelaPrincipal(root,login,cargo)
    root.mainloop()

login, cargo = controller.valida_Login()
iniciar_Tela_Principal(login, cargo)