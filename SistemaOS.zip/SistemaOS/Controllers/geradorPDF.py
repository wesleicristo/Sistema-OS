import datetime

from fpdf import FPDF

def gerarPDF(linhaOS=None, linhaPlan=None, linhaExe=None):
    pdf = FPDF()
    pdf.add_page()

    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="ORDEM DE SERVIÇO", ln=True, align="C")

    if True:
        pdf.set_font("Arial", size=10)
        pdf.cell(200, 10, txt=(f"Testando esse trem com quebra de \n linha"))

    pdf.output(f"pdf/Relatorio{datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S')}.pdf")
