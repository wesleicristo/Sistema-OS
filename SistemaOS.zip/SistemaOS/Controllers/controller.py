from Controllers import dbConect as db
from Views.telaLogin import iniciar_Tela_Login
from Controllers import geradorPDF as pdf

matriculaLogin = None
cargoLogin = None

def valida_Login():
    matricula, senha, cargo = None, None, None
    count = 0
    while not matricula:
        matricula, senha = iniciar_Tela_Login('' if count <= 0 else "Login invalido!")
        conexao = db.conexao_Banco()
        matricula, cargo = db.valida_Login(conexao, matricula, senha)
        count += 1
    matriculaLogin = matricula
    cargoLogin = cargo
    print(f"{matriculaLogin},{matricula} - {cargoLogin},{cargo}")
    return matricula, cargo

def get_cargoLogin():
    return cargoLogin

def pesquisar_OS(idos=None, unidade=None, tpos=None, estadoos=None):
    conexao = db.conexao_Banco()
    lista = db.consulta_OS(conexao, idos, unidade, tpos, estadoos)
    return lista

def pesquisar_Detalhes(numeroos=None):
    resultadoOS = None
    resultadoPlan = None
    resultadoExec = None
    executores = None
    conexao = db.conexao_Banco()
    resultadoOS, resultadoPlan, resultadoExec, executores = db.detalhes_OS(conexao, numeroos)
    return resultadoOS, resultadoPlan, resultadoExec, executores

def pesquisa_Ultima_OS(matriculaLogin=None):
    conexao = db.conexao_Banco()
    ultimaOS = db.Ultima_OS(conexao)
    infFuncionario = db.busca_Inf_Funcionario(conexao, matriculaLogin)
    return ultimaOS, infFuncionario

def pesquisa_Ultimo_Plan():
    conexao = db.conexao_Banco()
    ultimoPlan = db.ultimo_Plan(conexao)
    return ultimoPlan

def pesquisa_Ultimo_Exec():
    conexao = db.conexao_Banco()
    ultimoExec = db.ultimo_Exec(conexao)
    return ultimoExec

def pesquisa_Executores(matriculaLogin):
    conexao = db.conexao_Banco()
    listaMat, listaFunc = db.buscar_Executores(conexao, matriculaLogin)
    return listaMat, listaFunc



def salvar_NovaOS(linha):
    conexao = db.conexao_Banco()
    sucesso = db.gravar_NovaOS(conexao, linha)
    if sucesso: conexao.commit()
    return sucesso

def salvar_NovoPlan(linha):
    sucesso = False
    conexao = db.conexao_Banco()
    sucesso = db.gravar_NovoPlan(conexao, linha)
    return sucesso

def salvar_NovoExec(linha, executores):
    sucesso = False
    conexao = db.conexao_Banco()
    sucesso = db.gravar_NovoExec(conexao, linha, executores)
    return sucesso

def salvar_NumPlan_NumOS(numeroOS, numeroPlan): # Funcão descartada
    conexao = db.conexao_Banco()
    sucesso = db.alterar_Plan_OS(conexao, numeroOS, numeroPlan)
    return sucesso

def alterar_OS(numeroOS, nvDados):
    conexao = db.conexao_Banco()
    sucesso = db.alterar_OS(conexao, numeroOS, nvDados)
    if conexao: conexao.commit()
    return sucesso

def gerarPDF(linhaOS=None, linhaPlan=None, linhaExec=None):
    pdf.gerarPDF(linhaOS)
