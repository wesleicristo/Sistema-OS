import cx_Oracle

def conexao_Banco():
    try:
        conn = cx_Oracle.connect('ADMIN/ADMIN@localhost:1522/xe')
        return conn
    except:
        print(f"Erro ao conectar no banco de dados: {cx_Oracle.Error}")
        return None


def valida_Login(conexao, diglogin, digsenha):
    try:
        cursor = conexao.cursor()
        cursor.execute(f"SELECT matricula, senha, cargo"
                       f"\nFROM funcionario"
                       f"\nWHERE matricula = '{diglogin}' AND senha = {digsenha}")
        try:
            matricula, senha, cargo = cursor.fetchone()
        except:
            matricula, senha, cargo = '0','0','0'

        cursor.close()
        if str(matricula) == diglogin and senha == digsenha:
            return str(matricula), str(cargo)
        else:
            return None, None
    except cx_Oracle.Error as erro:
        print(f"Erro na busca: {erro}")
        return None, None

def consulta_OS(conexao, numero=None, unidade=None, tipo=None, estado=None):
    try:
        consultatxt = "SELECT ordem_servico.id, ordem_servico.titulo, unidade.nome, ordem_servico.descsolicit, ordem_servico.dtcria, ordem_servico.dtfecha, ordem_servico.tp_os, funcionario.nome FROM ordem_servico JOIN funcionario ON ordem_servico.funcionario_matricula = funcionario.matricula JOIN unidade ON funcionario.unidade_id = unidade.id"
        if numero:
            consultatxt += (f" WHERE ordem_servico.id = {numero}")
        if unidade:
            if numero:
                consultatxt += (f" AND unidade.id = {unidade}")
            else:
                consultatxt += (f" WHERE unidade.id = {unidade}")
        if tipo and tipo != "Tudo":
            if numero or unidade:
                consultatxt += (f" AND tp_os = '{tipo}'")
            else:
                consultatxt += (f" WHERE tp_os = '{tipo}'")
        if estado == "Aberta":
            if numero or unidade or tipo or tipo != "Tudo":
                consultatxt += (f" AND ordem_servico.dtfecha IS NULL")
            else:
                consultatxt += (f" WHERE ordem_servico.dtfecha IS NULL")
        elif estado == "Fechada":
            if numero or unidade or tipo or tipo != "Tudo":
                consultatxt += (f" AND ordem_servico.dtfecha IS NOT NULL")
            else:
                consultatxt += (f" WHERE ordem_servico.dtfecha IS NOT NULL")

        cursor = conexao.cursor()
        cursor.execute(consultatxt)
        resultado = cursor.fetchall()
        return resultado

    except cx_Oracle.Error as erro:
        print(f"Erro na consulta: {erro}")
    pass

def busca_projeto(conexao, numeroPlan):
    cursor = conexao.cursor()
    consultatxt = (f"SELECT planejamento.id, planejamento.dtinicio, planejamento.dtfinal, funcionario.nome, "
                   f"planejamento.descplanej "
                   f"\nFROM planejamento "
                   f"\nJOIN funcionario ON planejamento.funcionario_matricula = funcionario.matricula "
                   f"\nWHERE planejamento.id = {str(numeroPlan)}")
    cursor.execute(consultatxt)
    resultado = cursor.fetchone()
    return resultado

def buscar_executores_execucao(conexao, numeroExecFunc):
    resultado = None
    cursor = conexao.cursor()
    consultatxt = (f"SELECT funcionario.nome "
                   f"\nFROM ordem_execucao "
                   f"\nJOIN execucao_funcionario ON ordem_execucao.id = execucao_funcionario.ordem_execucao_id "
                   f"\nJOIN funcionario ON execucao_funcionario.funcionario_matricula = funcionario.matricula "
                   f"\nWHERE ordem_execucao.id = {str(numeroExecFunc)}")
    cursor.execute(consultatxt)
    resultado = cursor.fetchall()
    listaFunc = [resultado[0] for resultado in resultado]
    print(f"{listaFunc}")
    return listaFunc

def busca_execucao(conexao, numeroExec):
    resultado = None
    executores = None
    cursor = conexao.cursor()
    consultatxt = (f"SELECT ordem_execucao.id, ordem_execucao.dtinicio, ordem_execucao.dtfinal, "
                   f"ordem_execucao.vlrmaoobra, ordem_execucao.relatexec "
                   f"\nFROM ordem_execucao "
                   f"\nWHERE ordem_execucao.id = {str(numeroExec)}")
    cursor.execute(consultatxt)
    resultado = cursor.fetchone()
    executores = buscar_executores_execucao(conexao, numeroExec)
    return resultado, executores

def detalhes_OS(conexao, numeroos=None):
    resultadoOS = None
    resultadoPlan = None
    resultadoExec = None
    executores = None
    cursor = conexao.cursor()
    consultatxt = (f"SELECT ordem_servico.id, ordem_servico.titulo, unidade.nome, ordem_servico.dtcria, "
                   f"ordem_servico.dtfecha, ordem_servico.tp_os, funcionario.nome as requis, ordem_servico.descsolicit, "
                   f"ordem_servico.planejamento_id, ordem_servico.ordem_execucao_id  "
                   f"\nFROM ordem_servico "
                   f"\nJOIN funcionario ON ordem_servico.funcionario_matricula = funcionario.matricula "
                   f"\nJOIN unidade ON funcionario.unidade_id = unidade.id ")
    if numeroos:
        consultatxt += "WHERE ordem_servico.id = " + numeroos
    cursor.execute(consultatxt)
    resultadoOS = cursor.fetchone()
    cursor.close()
    if resultadoOS[8]:
        resultadoPlan = busca_projeto(conexao, resultadoOS[8])
    if resultadoOS[9]:
        resultadoExec, executores = busca_execucao(conexao, resultadoOS[9])
    return resultadoOS, resultadoPlan, resultadoExec, executores

def gravar_NovaOS(conexao, linha):
    try:
        idOS, titulo, descrSolic, dtInicio, tpOS, funcionario = linha
        cursor = conexao.cursor()
        gravartxt = (f"INSERT INTO ordem_servico (id, titulo, descsolicit, dtcria, tp_os, funcionario_matricula) "
                     f"\nVALUES ({idOS}, '{titulo}','{descrSolic}',TO_DATE('{dtInicio}','YYYY-MM-DD'),'{tpOS}',{funcionario})")
        cursor.execute(gravartxt)
        cursor.close()
        return True
    except cx_Oracle.Error as erro:
        print(f"Falha na gravação: {erro}")
        return False

def alterar_OS(conexao, numeroOS, linha):
    try:
        titulo, tpOS, descrSolic = linha
        cursor = conexao.cursor()
        alterartxt = (f"UPDATE ordem_servico SET titulo = '{titulo}', tp_os = '{tpOS}', descsolicit = '{descrSolic}'"
                      f"\nWHERE ordem_servico.id = {numeroOS}")
        cursor.execute(alterartxt)
        cursor.close()
        return True
    except cx_Oracle.Error as erro:
        print(f"Falha na gravação: {erro}")
        return False

def alterar_Plan_OS(conexao, numeroOS, numeroPlan): # funcão descartada
    try:
        cursor = conexao.cursor()
        alterartxt = (f"UPDATE ordem_servico SET planejamento_id = {str(numeroPlan)} WHERE id = {str(numeroOS)}")
        cursor.execute(alterartxt)
        cursor.close()
        return True
    except cx_Oracle.Error as erro:
        print(f"Falha na gravação: {erro}")
        return False
    pass

def gravar_NovoPlan(conexao, linha):
    try:
        cursor = conexao.cursor()
        idPlan, descplanej, dtinicio, dtfinal, func_matricula, idOS = linha
        gravartxt = (f"BEGIN "
                     f"\nSAVEPOINT cadastro_planejamento; "
                     f"\nINSERT INTO planejamento(id, descplanej, dtinicio, dtfinal, funcionario_matricula)"
                     f"\nVALUES({idPlan}, '{descplanej}', TO_DATE('{dtinicio}', 'YYYY-MM-DD'), TO_DATE('{dtfinal}', 'YYYY-MM-DD'), {func_matricula}); "
                     f"\nDECLARE id_planejamento planejamento.id%TYPE;"
                     f"\nBEGIN"
                     f"\nSELECT planejamento.id INTO id_planejamento FROM planejamento WHERE planejamento.id = {idPlan};"
                     f"\nUPDATE ordem_servico SET ordem_servico.planejamento_id = id_planejamento WHERE ordem_servico.id = {idOS};"
                     f"\nCOMMIT;"
                     f"\nEND;"
                     f"\nEXCEPTION"
                     f"\nWHEN OTHERS THEN ROLLBACK TO SAVEPOINT cadastro_planejamento;"
                     f"\nEND;")
        print(f"SQL Plan: {gravartxt}")
        cursor.execute(gravartxt)
        cursor.close()
        return True
    except cx_Oracle.Error as erro:
        print(f"Falha na gravação: {erro}")
        return False

def gravar_NovoExec(conexao, linha, executores):
    try:
        cursor = conexao.cursor()
        idExec, relatExec, dtInicio, dtFinal, vlMaoObra, idOS = linha
        gravartxt = (f"BEGIN"
                     f"\nSAVEPOINT cadastro_execucao;"
                     f"\nINSERT INTO ordem_execucao (id, relatexec, dtinicio, dtfinal, vlrmaoobra) VALUES ({idExec}, '{relatExec}', TO_DATE('{dtInicio}', 'YYYY-MM-DD'), TO_DATE('{dtFinal}', 'YYYY-MM-DD'), {vlMaoObra});"
                     f"\nDECLARE id_ordem_execucao ordem_execucao.id % TYPE;"
                     f"\nBEGIN"
                     f"\nSELECT ordem_execucao.id INTO id_ordem_execucao FROM ordem_execucao WHERE ordem_execucao.id = {idExec};"
                     f"\nUPDATE ordem_servico SET ordem_servico.ordem_execucao_id = id_ordem_execucao, ordem_servico.dtfecha = TO_DATE('{dtFinal}', 'YYYY-MM-DD') WHERE ordem_servico.id = {idOS};"
                     f"\nCOMMIT;"
                     f"\nEND;"
                     f"\nDECLARE ult_exec_func execucao_funcionario.id % TYPE;"
                     f"\nBEGIN")
        for executor in executores:
            gravartxt += (f"\nSELECT MAX(execucao_funcionario.id)+1 INTO ult_exec_func FROM execucao_funcionario;"
                          f"\nINSERT INTO execucao_funcionario(id, ordem_execucao_id, funcionario_matricula) VALUES (ult_exec_func, {idExec}, {executor});")

        gravartxt += (f"\nCOMMIT;"
                     f"\nEND;"
                     f"\nEXCEPTION"
                     f"\nWHEN OTHERS THEN ROLLBACK TO SAVEPOINT cadastro_execucao;"
                     f"\nEND;")
        print(f"SQL Exec: {gravartxt}")
        cursor.execute(gravartxt)
        cursor.close()
        return True
    except cx_Oracle.Error as erro:
        print(f"Falha na gravação: {erro}")
        return False


def nova_Exec():
    pass

def Ultima_OS(conexao):
    cursor = conexao.cursor()
    consultatxt = ("SELECT MAX(id)+1 FROM ordem_servico")
    cursor.execute(consultatxt)
    ult_IDOS = cursor.fetchone()[0]
    cursor.close()
    return ult_IDOS

def ultimo_Plan(conexao):
    cursor = conexao.cursor()
    consultatxt = ("SELECT MAX(id)+1 FROM planejamento")
    cursor.execute(consultatxt)
    ult_Plan = str(cursor.fetchone()[0])
    cursor.close()
    return ult_Plan

def ultimo_Exec(conexao):
    cursor = conexao.cursor()
    consultatxt = ("SELECT MAX(id)+1 FROM ordem_execucao")
    cursor.execute(consultatxt)
    ult_Exec = str(cursor.fetchone()[0])
    cursor.close()
    return ult_Exec

def busca_Inf_Funcionario(conexao, matriculaLogin):
    cursor = conexao.cursor()
    consultatxt = (f"SELECT unidade.nome, funcionario.nome "
                   f"\nFROM funcionario "
                   f"\nJOIN unidade ON unidade.id = funcionario.unidade_id "
                   f"\nWHERE funcionario.matricula = {str(matriculaLogin)}")
    cursor.execute(consultatxt)
    inf_Funcionario = cursor.fetchone()
    return inf_Funcionario

def buscar_Executores(conexao, matriculaLogin):
    cursor = conexao.cursor()
    consultatxt = (f"SELECT funcionario.matricula, funcionario.nome"
                   f"\nFROM funcionario"
                   f"\nWHERE funcionario.cargo = 'Executor' AND funcionario.matricula <> {matriculaLogin}")
    cursor.execute(consultatxt)
    resultado = cursor.fetchall()
    listaMat = [resultado[0] for resultado in resultado]
    listaFunc = [resultado[1] for resultado in resultado]
    return listaMat, listaFunc